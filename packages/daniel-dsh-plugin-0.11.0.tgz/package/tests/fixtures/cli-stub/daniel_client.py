# -*- coding: utf-8 -*-
"""测试用假客户端：只实现 add-items 需要的读/写面，数据来自 FAKE_WORLD（JSON）。

它不是产品代码，只用于"真 CLI 子进程 + 假数据源"的集成测试：
  · 读：items(listId) / channel_detail(channelId=...)
  · 写：mutate("lists.batchAddItems", {listId, items})
  · 每次调用追加一行到 FAKE_CALLS（测试据此断言"干跑没有写请求"）
"""
import json
import os

SESSION_FILE = "<fake-session>"


def _read_session_cookie():
    return ("fake-session-token", False)


class Daniel:
    def __init__(self, verbose=False):
        self.verbose = verbose

    def login(self):
        return True

    def _world(self):
        with open(os.environ["FAKE_WORLD"], encoding="utf-8") as fh:
            return json.load(fh)

    def _save(self, world):
        path = os.environ.get("FAKE_WORLD")
        if path:
            with open(path, "w", encoding="utf-8") as fh:
                json.dump(world, fh, ensure_ascii=False, indent=1)

    def _log(self, kind, **kw):
        path = os.environ.get("FAKE_CALLS")
        if not path:
            return
        with open(path, "a", encoding="utf-8") as fh:
            fh.write(json.dumps({"kind": kind, **kw}, ensure_ascii=False) + "\n")

    # ── 读 ──
    def query(self, route, inp=None, **kw):
        self._log("query", route=route, payload=inp)
        if route == "lists.getItems":
            return self.items((inp or {}).get("listId"))
        return []

    def items(self, list_id):
        world = self._world()
        return [dict(r) for r in (world.get("lists") or {}).get(str(list_id), [])]

    def channel_detail(self, **kw):
        cid = kw.get("channelId")
        self._log("detail", channelId=cid)
        world = self._world()
        if cid in (world.get("failDetails") or []):
            raise RuntimeError("HTTP 500 模拟详情失败")
        return dict((world.get("details") or {}).get(cid) or {})

    def resolve_brand_ref(self, ref):
        return {"id": 3690002, "name": "Halliday", "workspaceId": 90002,
                "category": "AI Glasses", "competitors": []}

    # ── 写 ──
    def mutate(self, route, inp=None, **kw):
        self._log("mutate", route=route, payload=inp)
        if route != "lists.batchAddItems":
            return {}
        world = self._world()
        list_id = str((inp or {}).get("listId"))
        rows = world.setdefault("lists", {}).setdefault(list_id, [])
        items = list((inp or {}).get("items") or [])
        if (world.get("mutateMode") or "normal") == "drop_one":
            items = items[:-1]
        existing = {r.get("channelId") for r in rows}
        added = [dict(it) for it in items if it.get("channelId") not in existing]
        rows.extend(added)
        self._save(world)
        return {"addedCount": len(added), "failed": []}
